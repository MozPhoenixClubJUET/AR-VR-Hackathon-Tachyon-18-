﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
	public float speed = 8;
	Vector3 targetPos;
	GameObject ballObj;
	
	void Start()
	{
		ballObj = GameObject.FindGameObjectWithTag("Ball");
	}
	
	void Update()
	{
		targetPos = Vector3.Lerp(transform.position, ballObj.transform.position, Time.deltaTime * speed);
		
		transform.position = new Vector3(20, targetPos.y, 0);
	}
}