﻿using UnityEngine;
using System.Collections;

public class paddle : MonoBehaviour {
	public float paddleSpeed = 1F;
	public Vector3 playerPos = new Vector3(0,0,0);

	void Update ()
	{
		float ypos = gameObject.transform.position.y + (Input.GetAxis ("Vertical") * paddleSpeed);
		playerPos = new Vector3 (-20, Mathf.Clamp (ypos, -11, 11), 0);
		gameObject.transform.position = playerPos;
	}
}